/**
 * A model representing the intention of a message. 
 */

module.exports = Intent;

function Intent(name) {
    this.name = name;
}